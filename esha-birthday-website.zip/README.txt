ESHA BIRTHDAY SURPRISE WEBSITE
1. Upload index.html to your existing GitHub repository and replace the old index.html.
2. Keep the filename exactly index.html.
3. GitHub Pages: Settings > Pages > Deploy from a branch > main > /(root) > Save.
4. Wait a few minutes, then open:
https://husainabbas8169-star.github.io/esha-birthday-surprise/

The site works on mobile, has animations, a virtual cake, India/Pakistan-themed distance section,
birthday shayari, a gift with hidden message, and floating hearts. It uses no paid services.
The distance section is symbolic, not an exact live distance calculator.
